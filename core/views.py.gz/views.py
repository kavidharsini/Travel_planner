from django.shortcuts import render, redirect, get_object_or_404
from .models import Product

def homepage(request):
    return render(request, 'core/homepage.html')

def products(request):
    items = Product.objects.all()
    return render(request, 'core/products.html', {'items': items})

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        # Handle form submission (e.g., save to database or send email)
        return redirect('homepage')
    return render(request, 'core/contact.html')

def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    if product_id in cart:
        cart[product_id] += 1  # Increment quantity
    else:
        cart[product_id] = 1  # Add new item with quantity 1
    request.session['cart'] = cart
    return redirect('products')

# core/views.py

def view_cart(request):
    cart = request.session.get('cart', {})
    product_ids = cart.keys()
    products = Product.objects.filter(id__in=product_ids)
    cart_items = [(product, cart[str(product.id)]) for product in products]
    return render(request, 'core/view_cart.html', {'cart_items': cart_items})
